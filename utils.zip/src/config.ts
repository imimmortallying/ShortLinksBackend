module.exports = {
    JWT_ACCESS_SECRET: 'jwt-access-seret-key',
    JWT_REFRESH_SECRET: 'jwt-refresh-seret-key'
}