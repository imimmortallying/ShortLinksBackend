import { User, UserProps } from "./user.model";

export {
    User,
    UserProps
}