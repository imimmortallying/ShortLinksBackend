
export interface UserUriIdString {
    id:string;
}