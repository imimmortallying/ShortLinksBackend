
// попробовал назвать как эндпоинт/метод/что внутри запроса/model т.е. форма этой сущности

export interface UsersPostBodyModel {
    name:string, 
    specialty:string
}