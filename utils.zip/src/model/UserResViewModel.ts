
// попробовал назвать как эндпоинт/response/функция?/model т.е. форма этой сущности

export interface UserResViewModel {
    /**
     * response User model 
     */
    id: string,
    name: string,
    specialty: string,
}