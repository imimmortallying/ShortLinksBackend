
export interface UserPostCreateBodyModel {
    /**
     * model of request to create a new user
     */
    username: string,
    password: string,
}